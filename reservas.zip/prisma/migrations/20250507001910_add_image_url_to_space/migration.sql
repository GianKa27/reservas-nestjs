-- AlterTable
ALTER TABLE `Space` ADD COLUMN `imageUrl` VARCHAR(1024) NULL;
